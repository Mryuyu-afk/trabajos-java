# Sistema de Registro de Empleados (Java Swing)

## Estructura
- `src/Main.java` — método `main` y toda la lógica (validaciones, lista de empleados, estadísticas).
- `src/VentanaEmpleados.java` — JFrame con la interfaz visual (formulario, botones, tabla, estadísticas).
- `src/Empleado.java` — clase modelo.

## Compilar y ejecutar (JDK 8 o superior)
    mkdir out
    javac -encoding UTF-8 -d out src/*.java
    java -cp out Main

En NetBeans / IntelliJ / Eclipse: cree un proyecto Java vacío, copie los 3 archivos
a `src` y ejecute `Main`.
