import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.text.ParseException;

/**
 * Interfaz visual (JFrame) del Sistema de Registro de Empleados.
 * Solo se encarga de mostrar los controles; la lógica está en Main.
 */
public class VentanaEmpleados extends JFrame {

    private static final String SELECCIONE = "Seleccione...";

    // Campos del formulario
    private final JTextField txtNombre = new JTextField(22);
    private final JTextField txtDocumento = new JTextField(22);
    private final JComboBox<String> cmbCargo = new JComboBox<>();
    private final JComboBox<String> cmbArea = new JComboBox<>();
    private final JSpinner spnSalario =
            new JSpinner(new SpinnerNumberModel(0.0, 0.0, 1_000_000_000.0, 50_000.0));
    private JFormattedTextField txtFecha;

    // Tabla
    private final DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"NOMBRE", "DOCUMENTO", "CARGO", "ÁREA", "SALARIO"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // la tabla es solo de lectura
        }
    };
    private final JTable tabla = new JTable(modelo);

    // Estadísticas
    private final JLabel lblCantidad = new JLabel();
    private final JLabel lblPromedio = new JLabel();
    private final JLabel lblMayor = new JLabel();

    public VentanaEmpleados() {
        super("Sistema de Registro de Empleados");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        ((JComponent) getContentPane()).setBorder(new EmptyBorder(12, 12, 12, 12));

        configurarControles();

        add(crearTitulo(), BorderLayout.NORTH);
        add(crearCentro(), BorderLayout.CENTER);
        add(crearEstadisticas(), BorderLayout.SOUTH);

        actualizarEstadisticas();
        pack();
        setMinimumSize(new Dimension(760, 620));
        setLocationRelativeTo(null);
    }

    // ================== Construcción de la interfaz ==================

    private void configurarControles() {
        cmbCargo.addItem(SELECCIONE);
        for (String c : Main.CARGOS) cmbCargo.addItem(c);

        cmbArea.addItem(SELECCIONE);
        for (String a : Main.AREAS) cmbArea.addItem(a);

        spnSalario.setEditor(new JSpinner.NumberEditor(spnSalario, "#,##0"));

        try {
            MaskFormatter mascara = new MaskFormatter("##/##/####");
            mascara.setPlaceholderCharacter('_');
            txtFecha = new JFormattedTextField(mascara);
        } catch (ParseException e) {
            txtFecha = new JFormattedTextField();
        }
        txtFecha.setColumns(10);
        txtFecha.setToolTipText("Formato: dd/MM/aaaa");

        tabla.setRowHeight(24);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.getTableHeader().setReorderingAllowed(false);
        tabla.setFillsViewportHeight(true);
    }

    private JComponent crearTitulo() {
        JLabel titulo = new JLabel("REGISTRO DE EMPLEADOS", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 24f));
        titulo.setBorder(new EmptyBorder(0, 0, 4, 0));
        return titulo;
    }

    private JComponent crearCentro() {
        JPanel centro = new JPanel(new BorderLayout(10, 10));
        centro.add(crearFormulario(), BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(new TitledBorder("Empleados registrados"));
        centro.add(scroll, BorderLayout.CENTER);
        return centro;
    }

    private JComponent crearFormulario() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new TitledBorder("Datos del empleado"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Columna izquierda
        agregarFila(form, gbc, 0, 0, "Nombre Completo:", txtNombre);
        agregarFila(form, gbc, 1, 0, "Cargo:", cmbCargo);
        agregarFila(form, gbc, 2, 0, "Salario:", spnSalario);

        // Columna derecha
        agregarFila(form, gbc, 0, 2, "Documento:", txtDocumento);
        agregarFila(form, gbc, 1, 2, "Área:", cmbArea);
        agregarFila(form, gbc, 2, 2, "Fecha de Ingreso:", txtFecha);

        // Botones
        JButton btnGuardar = new JButton("Guardar");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnEliminar = new JButton("Eliminar Registro");

        btnGuardar.addActionListener(e -> guardar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnEliminar.addActionListener(e -> eliminar());

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        botones.add(btnGuardar);
        botones.add(btnLimpiar);
        botones.add(btnEliminar);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 4;
        form.add(botones, gbc);

        return form;
    }

    private void agregarFila(JPanel panel, GridBagConstraints gbc, int fila, int col,
                             String etiqueta, JComponent campo) {
        gbc.gridwidth = 1;
        gbc.gridy = fila;

        gbc.gridx = col;
        gbc.weightx = 0;
        panel.add(new JLabel(etiqueta), gbc);

        gbc.gridx = col + 1;
        gbc.weightx = 1;
        panel.add(campo, gbc);
    }

    private JComponent crearEstadisticas() {
        JPanel panel = new JPanel(new GridLayout(1, 3, 15, 0));
        panel.setBorder(new TitledBorder("Estadísticas"));
        panel.add(lblCantidad);
        panel.add(lblPromedio);
        panel.add(lblMayor);
        return panel;
    }

    // ================== Acciones de los botones ==================

    private void guardar() {
        // Capturar datos del formulario
        try {
            spnSalario.commitEdit(); // asegura que el valor escrito a mano quede aplicado
        } catch (ParseException ex) {
            // se usa el último valor válido del spinner
        }
        String nombre = txtNombre.getText();
        String documento = txtDocumento.getText();
        String cargo = cmbCargo.getSelectedIndex() <= 0 ? "" : (String) cmbCargo.getSelectedItem();
        String area = cmbArea.getSelectedIndex() <= 0 ? "" : (String) cmbArea.getSelectedItem();
        double salario = ((Number) spnSalario.getValue()).doubleValue();
        String fecha = txtFecha.getText();

        // Validar (lógica en Main)
        String error = Main.validar(nombre, documento, cargo, area, salario, fecha);
        if (error != null) {
            JOptionPane.showMessageDialog(this, error, "Datos incompletos o inválidos",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Guardar y agregar a la tabla
        Empleado emp = Main.agregarEmpleado(nombre, documento, cargo, area, salario, fecha);
        modelo.addRow(new Object[]{
                emp.getNombre(), emp.getDocumento(), emp.getCargo(), emp.getArea(),
                Main.formatoMoneda(emp.getSalario())
        });

        actualizarEstadisticas();
        limpiar();
        JOptionPane.showMessageDialog(this, "Empleado registrado correctamente.",
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void limpiar() {
        txtNombre.setText("");
        txtDocumento.setText("");
        cmbCargo.setSelectedIndex(0);
        cmbArea.setSelectedIndex(0);
        spnSalario.setValue(0.0);
        txtFecha.setValue(null);
        txtFecha.setText("");
        tabla.clearSelection();
        txtNombre.requestFocusInWindow();
    }

    private void eliminar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila de la tabla para eliminarla.",
                    "Sin selección", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Desea eliminar el registro de " + modelo.getValueAt(fila, 0) + "?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            Main.eliminarEmpleado(fila);
            modelo.removeRow(fila);
            actualizarEstadisticas();
        }
    }

    private void actualizarEstadisticas() {
        lblCantidad.setText("Empleados registrados: " + Main.cantidadEmpleados());
        lblPromedio.setText("Promedio salarial: " + Main.formatoMoneda(Main.promedioSalarial()));

        Empleado mayor = Main.empleadoMayorSalario();
        lblMayor.setText(mayor == null
                ? "Mayor salario: -"
                : "Mayor salario: " + mayor.getNombre() + " (" + Main.formatoMoneda(mayor.getSalario()) + ")");
    }
}
