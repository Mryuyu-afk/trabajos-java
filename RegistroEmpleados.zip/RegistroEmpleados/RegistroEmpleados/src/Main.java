import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Clase principal. Contiene el método main y toda la LÓGICA del proyecto:
 * lista de empleados, validaciones y estadísticas.
 * La interfaz gráfica vive en VentanaEmpleados.
 */
public class Main {

    // ---------- Datos ----------
    public static final String[] CARGOS = {"Auxiliar", "Analista", "Supervisor", "Coordinador"};
    public static final String[] AREAS  = {"Recursos Humanos", "Sistemas", "Contabilidad", "Producción"};

    public static final DateTimeFormatter FORMATO_FECHA =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    private static final List<Empleado> empleados = new ArrayList<>();

    // ---------- Punto de entrada ----------
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignorada) {
            // Si falla, se usa el aspecto por defecto de Swing
        }
        SwingUtilities.invokeLater(() -> new VentanaEmpleados().setVisible(true));
    }

    // ---------- Lógica: validación ----------

    /**
     * Valida los datos del formulario.
     * @return null si todo es correcto; en caso contrario, el mensaje de error a mostrar.
     */
    public static String validar(String nombre, String documento, String cargo,
                                 String area, double salario, String fecha) {

        // Nivel básico/intermedio: ningún campo puede estar vacío
        List<String> faltantes = new ArrayList<>();
        if (nombre.trim().isEmpty())     faltantes.add("Nombre Completo");
        if (documento.trim().isEmpty())  faltantes.add("Documento");
        if (cargo.isEmpty())             faltantes.add("Cargo");
        if (area.isEmpty())              faltantes.add("Área");
        if (fecha.replaceAll("[_/\\s]", "").isEmpty()) faltantes.add("Fecha de Ingreso");

        if (!faltantes.isEmpty()) {
            return "Falta información. Complete los siguientes campos:\n- "
                    + String.join("\n- ", faltantes);
        }

        // Nivel intermedio: el salario debe ser mayor a 0
        if (salario <= 0) {
            return "El salario debe ser mayor a 0.";
        }

        // Fecha válida (dd/MM/aaaa) y no futura
        LocalDate fechaIngreso;
        try {
            fechaIngreso = LocalDate.parse(fecha, FORMATO_FECHA);
        } catch (DateTimeParseException e) {
            return "La fecha de ingreso no es válida. Use el formato dd/MM/aaaa.";
        }
        if (fechaIngreso.isAfter(LocalDate.now())) {
            return "La fecha de ingreso no puede ser posterior a hoy.";
        }

        // No repetir documentos
        for (Empleado e : empleados) {
            if (e.getDocumento().equalsIgnoreCase(documento.trim())) {
                return "Ya existe un empleado registrado con el documento " + documento.trim() + ".";
            }
        }
        return null;
    }

    // ---------- Lógica: operaciones sobre la lista ----------

    /** Crea el empleado y lo agrega a la lista (se asume que ya fue validado). */
    public static Empleado agregarEmpleado(String nombre, String documento, String cargo,
                                           String area, double salario, String fecha) {
        Empleado emp = new Empleado(nombre.trim(), documento.trim(), cargo, area,
                salario, LocalDate.parse(fecha, FORMATO_FECHA));
        empleados.add(emp);
        return emp;
    }

    /** Elimina el empleado que está en la posición indicada (misma posición que en la tabla). */
    public static void eliminarEmpleado(int indice) {
        if (indice >= 0 && indice < empleados.size()) {
            empleados.remove(indice);
        }
    }

    // ---------- Lógica: estadísticas (nivel avanzado) ----------

    public static int cantidadEmpleados() {
        return empleados.size();
    }

    public static double promedioSalarial() {
        if (empleados.isEmpty()) return 0;
        double suma = 0;
        for (Empleado e : empleados) suma += e.getSalario();
        return suma / empleados.size();
    }

    /** @return el empleado con mayor salario, o null si no hay registros. */
    public static Empleado empleadoMayorSalario() {
        Empleado mayor = null;
        for (Empleado e : empleados) {
            if (mayor == null || e.getSalario() > mayor.getSalario()) mayor = e;
        }
        return mayor;
    }

    // ---------- Utilidad ----------

    /** Formatea un valor como moneda, por ejemplo: $ 1.500.000 */
    public static String formatoMoneda(double valor) {
        DecimalFormat df = new DecimalFormat("$ #,##0",
                DecimalFormatSymbols.getInstance(Locale.forLanguageTag("es-CO")));
        return df.format(valor);
    }
}
