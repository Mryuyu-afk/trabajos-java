import java.time.LocalDate;

/**
 * Modelo de datos: representa a un empleado de la empresa.
 */
public class Empleado {

    private final String nombre;
    private final String documento;
    private final String cargo;
    private final String area;
    private final double salario;
    private final LocalDate fechaIngreso;

    public Empleado(String nombre, String documento, String cargo, String area,
                    double salario, LocalDate fechaIngreso) {
        this.nombre = nombre;
        this.documento = documento;
        this.cargo = cargo;
        this.area = area;
        this.salario = salario;
        this.fechaIngreso = fechaIngreso;
    }

    public String getNombre()        { return nombre; }
    public String getDocumento()     { return documento; }
    public String getCargo()         { return cargo; }
    public String getArea()          { return area; }
    public double getSalario()       { return salario; }
    public LocalDate getFechaIngreso() { return fechaIngreso; }
}
