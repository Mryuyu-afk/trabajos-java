package registroempleados;

import javax.swing.UIManager;

/**
 * Clase principal que ejecuta el Sistema de Registro de Empleados.
 * 
 * @author yurge
 */
public class RegistroEmpleados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Establecer el aspecto visual (Look and Feel)
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // Si ocurre algún error, continúa con el aspecto por defecto
            }
        }

        // Iniciar la interfaz gráfica de usuario
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                formulario ventana = new formulario();
                ventana.setVisible(true);
            }
        });
    }
}

