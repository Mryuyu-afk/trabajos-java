/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package registroempleados;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 * Formulario principal para el Registro y Gestión de Empleados.
 * Permite registrar, modificar, eliminar, buscar y listar empleados.
 * 
 * @author yurge
 */
public class formulario extends javax.swing.JFrame {

    // Lista en memoria para almacenar los empleados
    private final ArrayList<registro> listaEmpleados = new ArrayList<>();
    
    // Modelo de datos para la tabla
    private DefaultTableModel modeloTabla;
    private JLabel lblTotalNomina;

    /**
     * Creates new form formulario
     */
    public formulario() {
        initComponents();
        personalizarDisenio();
        configurarTabla();
        cargarDatosIniciales();
        actualizarEstadisticas();
    }

    /**
     * Aplica detalles de diseño visual, estilos, fuentes y comportamiento inicial.
     */
    private void personalizarDisenio() {
        // Centrar la ventana en la pantalla y configurar dimensiones
        this.setSize(1040, 680);
        this.setLocationRelativeTo(null);

        // Cursores de mano para los botones de acción
        btnRegistrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnModificar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnEliminar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLimpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBuscar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnMostrarTodos.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSalir.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Estilos de color para los botones
        btnRegistrar.setBackground(new Color(34, 153, 84));
        btnRegistrar.setForeground(Color.WHITE);

        btnModificar.setBackground(new Color(41, 128, 185));
        btnModificar.setForeground(Color.WHITE);

        btnEliminar.setBackground(new Color(192, 57, 43));
        btnEliminar.setForeground(Color.WHITE);

        btnLimpiar.setBackground(new Color(127, 140, 141));
        btnLimpiar.setForeground(Color.WHITE);

        btnSalir.setBackground(new Color(52, 73, 94));
        btnSalir.setForeground(Color.WHITE);

        btnBuscar.setBackground(new Color(44, 62, 80));
        btnBuscar.setForeground(Color.WHITE);

        btnMostrarTodos.setBackground(new Color(93, 109, 126));
        btnMostrarTodos.setForeground(Color.WHITE);

        // Deshabilitar botón modificar y eliminar al inicio (hasta que se seleccione una fila)
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
    }

    /**
     * Configura el encabezado, selección y columnas del JTable.
     */
    private void configurarTabla() {
        modeloTabla = (DefaultTableModel) tblEmpleados.getModel();
        tblEmpleados.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblEmpleados.setRowHeight(25);

        // Estilo del encabezado de la tabla
        JTableHeader header = tblEmpleados.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));
        header.setBackground(new Color(28, 43, 74));
        header.setForeground(Color.WHITE);
        header.setReorderingAllowed(false);

        // Anchos preferidos de columnas
        if (tblEmpleados.getColumnModel().getColumnCount() > 0) {
            tblEmpleados.getColumnModel().getColumn(0).setPreferredWidth(80);  // ID
            tblEmpleados.getColumnModel().getColumn(1).setPreferredWidth(120); // Nombres
            tblEmpleados.getColumnModel().getColumn(2).setPreferredWidth(120); // Apellidos
            tblEmpleados.getColumnModel().getColumn(3).setPreferredWidth(95);  // Teléfono
            tblEmpleados.getColumnModel().getColumn(4).setPreferredWidth(150); // Correo
            tblEmpleados.getColumnModel().getColumn(5).setPreferredWidth(130); // Departamento
            tblEmpleados.getColumnModel().getColumn(6).setPreferredWidth(130); // Cargo
            tblEmpleados.getColumnModel().getColumn(7).setPreferredWidth(90);  // Salario
            tblEmpleados.getColumnModel().getColumn(8).setPreferredWidth(80);  // Estado
        }
    }

    /**
     * Carga datos iniciales de ejemplo para facilitar la visualización inmediata.
     */
    private void cargarDatosIniciales() {
        registro emp1 = new registro("E001", "Carlos", "Mendoza Ramos", "0991234567", 
                                     "carlos.mendoza@empresa.com", "Sistemas / TI", 
                                     "Desarrollador de Software", 1850.00, "Activo");
        registro emp2 = new registro("E002", "Ana María", "Gómez Silva", "0987654321", 
                                     "ana.gomez@empresa.com", "Contabilidad y Finanzas", 
                                     "Contador Público", 1600.00, "Activo");
        registro emp3 = new registro("E003", "Roberto", "Torres Castro", "0978901234", 
                                     "roberto.torres@empresa.com", "Recursos Humanos", 
                                     "Gerente General", 2500.00, "Activo");

        agregarEmpleadoAListaYTabla(emp1);
        agregarEmpleadoAListaYTabla(emp2);
        agregarEmpleadoAListaYTabla(emp3);
    }

    /**
     * Agrega un objeto registro a la lista y a la tabla visual.
     */
    private void agregarEmpleadoAListaYTabla(registro emp) {
        listaEmpleados.add(emp);
        modeloTabla.addRow(emp.toTableRow());
    }

    /**
     * Actualiza las estadísticas de la barra inferior (total, nómina, promedio).
     */
    private void actualizarEstadisticas() {
        int total = listaEmpleados.size();
        double nomina = 0.0;
        for (registro emp : listaEmpleados) {
            nomina += emp.getSalario();
        }
        double promedio = total > 0 ? (nomina / total) : 0.0;

        lblTotalEmpleados.setText("Total Empleados: " + total);
        lblTotalNomina.setText(String.format("Total Nómina: $%.2f", nomina));
        lblPromedioSalario.setText(String.format("Promedio Salarial: $%.2f", promedio));
    }

    /**
     * Limpia los campos de texto y restablece los combos.
     */
    private void limpiarCampos() {
        txtId.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        cbxDepartamento.setSelectedIndex(0);
        cbxCargo.setSelectedIndex(0);
        txtSalario.setText("");
        cbxEstado.setSelectedIndex(0);

        txtId.setEditable(true);
        tblEmpleados.clearSelection();
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnRegistrar.setEnabled(true);
        txtId.requestFocus();
    }

    /**
     * Valida que los campos obligatorios no estén vacíos y contengan datos correctos.
     */
    private boolean validarCampos() {
        if (txtId.getText().trim().isEmpty()) {
            mostrarMensaje("El Código / Cédula es obligatorio.", "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            txtId.requestFocus();
            return false;
        }
        if (txtNombres.getText().trim().isEmpty()) {
            mostrarMensaje("Los Nombres son obligatorios.", "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            txtNombres.requestFocus();
            return false;
        }
        if (txtApellidos.getText().trim().isEmpty()) {
            mostrarMensaje("Los Apellidos son obligatorios.", "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            txtApellidos.requestFocus();
            return false;
        }
        if (cbxDepartamento.getSelectedIndex() == 0) {
            mostrarMensaje("Por favor seleccione un Departamento.", "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            cbxDepartamento.requestFocus();
            return false;
        }
        if (cbxCargo.getSelectedIndex() == 0) {
            mostrarMensaje("Por favor seleccione un Cargo / Puesto.", "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            cbxCargo.requestFocus();
            return false;
        }
        if (txtSalario.getText().trim().isEmpty()) {
            mostrarMensaje("El Salario es obligatorio.", "Campo Requerido", JOptionPane.WARNING_MESSAGE);
            txtSalario.requestFocus();
            return false;
        }

        try {
            double salario = Double.parseDouble(txtSalario.getText().trim().replace(",", "."));
            if (salario <= 0) {
                mostrarMensaje("El salario debe ser un valor numérico positivo mayor a 0.", "Salario Inválido", JOptionPane.WARNING_MESSAGE);
                txtSalario.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            mostrarMensaje("El formato del salario no es válido. Ingrese solo números (ej: 1200.50).", "Salario Inválido", JOptionPane.ERROR_MESSAGE);
            txtSalario.requestFocus();
            return false;
        }

        return true;
    }

    /**
     * Verifica si un ID de empleado ya se encuentra registrado.
     */
    private boolean existeId(String id) {
        for (registro emp : listaEmpleados) {
            if (emp.getId().equalsIgnoreCase(id.trim())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Muestra cuadros de diálogo con mensajes al usuario.
     */
    private void mostrarMensaje(String mensaje, String titulo, int tipo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, tipo);
    }

    /**
     * Recarga toda la lista de empleados en la tabla.
     */
    private void recargarTabla() {
        modeloTabla.setRowCount(0);
        for (registro emp : listaEmpleados) {
            modeloTabla.addRow(emp.toTableRow());
        }
        actualizarEstadisticas();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelEncabezado = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblSubtitulo = new javax.swing.JLabel();
        panelCuerpo = new javax.swing.JPanel();
        panelFormulario = new javax.swing.JPanel();
        lblId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        lblNombres = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        lblApellidos = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        lblTelefono = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        lblCorreo = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        lblDepartamento = new javax.swing.JLabel();
        cbxDepartamento = new javax.swing.JComboBox<>();
        lblCargo = new javax.swing.JLabel();
        cbxCargo = new javax.swing.JComboBox<>();
        lblSalario = new javax.swing.JLabel();
        txtSalario = new javax.swing.JTextField();
        lblEstado = new javax.swing.JLabel();
        cbxEstado = new javax.swing.JComboBox<>();
        panelTablaContenedor = new javax.swing.JPanel();
        panelBusqueda = new javax.swing.JPanel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnMostrarTodos = new javax.swing.JButton();
        jScrollPaneTabla = new javax.swing.JScrollPane();
        tblEmpleados = new javax.swing.JTable();
        panelEstadisticas = new javax.swing.JPanel();
        lblTotalEmpleados = new javax.swing.JLabel();
        lblTotalNomina = new javax.swing.JLabel();
        lblPromedioSalario = new javax.swing.JLabel();
        panelBotones = new javax.swing.JPanel();
        btnRegistrar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de Registro de Empleados");

        panelEncabezado.setBackground(new java.awt.Color(28, 43, 74));
        panelEncabezado.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 20, 15, 20));
        panelEncabezado.setLayout(new java.awt.GridLayout(2, 1, 0, 5));

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("SISTEMA DE REGISTRO DE EMPLEADOS");
        panelEncabezado.add(lblTitulo);

        lblSubtitulo.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        lblSubtitulo.setForeground(new java.awt.Color(200, 215, 235));
        lblSubtitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSubtitulo.setText("Gestión y Control de Personal");
        panelEncabezado.add(lblSubtitulo);

        getContentPane().add(panelEncabezado, java.awt.BorderLayout.NORTH);

        panelCuerpo.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 15, 10, 15));
        panelCuerpo.setLayout(new java.awt.BorderLayout(10, 10));

        panelFormulario.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "  Datos del Empleado  ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 13), new java.awt.Color(28, 43, 74))); // NOI18N
        panelFormulario.setPreferredSize(new java.awt.Dimension(380, 480));
        panelFormulario.setLayout(new java.awt.GridLayout(9, 2, 8, 10));

        lblId.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblId.setText("Código / Cédula:");
        panelFormulario.add(lblId);
        panelFormulario.add(txtId);

        lblNombres.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNombres.setText("Nombres:");
        panelFormulario.add(lblNombres);
        panelFormulario.add(txtNombres);

        lblApellidos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblApellidos.setText("Apellidos:");
        panelFormulario.add(lblApellidos);
        panelFormulario.add(txtApellidos);

        lblTelefono.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTelefono.setText("Teléfono:");
        panelFormulario.add(lblTelefono);
        panelFormulario.add(txtTelefono);

        lblCorreo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCorreo.setText("Correo Electrónico:");
        panelFormulario.add(lblCorreo);
        panelFormulario.add(txtCorreo);

        lblDepartamento.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblDepartamento.setText("Departamento:");
        panelFormulario.add(lblDepartamento);

        cbxDepartamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Seleccionar --", "Recursos Humanos", "Sistemas / TI", "Contabilidad y Finanzas", "Ventas y Mercadeo", "Operaciones y Logística", "Administración General" }));
        panelFormulario.add(cbxDepartamento);

        lblCargo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblCargo.setText("Cargo / Puesto:");
        panelFormulario.add(lblCargo);

        cbxCargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Seleccionar --", "Gerente General", "Administrador", "Desarrollador de Software", "Analista de Sistemas", "Contador Público", "Auxiliar Administrativo", "Ejecutivo de Ventas", "Supervisor de Operaciones", "Operario" }));
        panelFormulario.add(cbxCargo);

        lblSalario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblSalario.setText("Salario Base ($):");
        panelFormulario.add(lblSalario);
        panelFormulario.add(txtSalario);

        lblEstado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblEstado.setText("Estado Laboral:");
        panelFormulario.add(lblEstado);

        cbxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo", "Vacaciones", "Licencia" }));
        panelFormulario.add(cbxEstado);

        panelCuerpo.add(panelFormulario, java.awt.BorderLayout.WEST);

        panelTablaContenedor.setLayout(new java.awt.BorderLayout(5, 8));

        panelBusqueda.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "  Búsqueda y Filtro  ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 12), new java.awt.Color(28, 43, 74))); // NOI18N
        panelBusqueda.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 5));

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBuscar.setText("Buscar:");
        panelBusqueda.add(lblBuscar);

        txtBuscar.setColumns(18);
        panelBusqueda.add(txtBuscar);

        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        panelBusqueda.add(btnBuscar);

        btnMostrarTodos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMostrarTodos.setText("Mostrar Todos");
        btnMostrarTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarTodosActionPerformed(evt);
            }
        });
        panelBusqueda.add(btnMostrarTodos);

        panelTablaContenedor.add(panelBusqueda, java.awt.BorderLayout.NORTH);

        tblEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombres", "Apellidos", "Teléfono", "Correo", "Departamento", "Cargo", "Salario ($)", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEmpleadosMouseClicked(evt);
            }
        });
        jScrollPaneTabla.setViewportView(tblEmpleados);

        panelTablaContenedor.add(jScrollPaneTabla, java.awt.BorderLayout.CENTER);

        panelEstadisticas.setBackground(new java.awt.Color(225, 232, 240));
        panelEstadisticas.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 10, 6, 10));
        panelEstadisticas.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 25, 5));

        lblTotalEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTotalEmpleados.setText("Total Empleados: 0");
        panelEstadisticas.add(lblTotalEmpleados);

        lblTotalNomina.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTotalNomina.setText("Total Nómina: $0.00");
        panelEstadisticas.add(lblTotalNomina);

        lblPromedioSalario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblPromedioSalario.setText("Promedio Salarial: $0.00");
        panelEstadisticas.add(lblPromedioSalario);

        panelTablaContenedor.add(panelEstadisticas, java.awt.BorderLayout.SOUTH);

        panelCuerpo.add(panelTablaContenedor, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelCuerpo, java.awt.BorderLayout.CENTER);

        panelBotones.setBackground(new java.awt.Color(230, 234, 240));
        panelBotones.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 10, 12, 10));
        panelBotones.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5));

        btnRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistrar.setText("Registrar Empleado");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        panelBotones.add(btnRegistrar);

        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        panelBotones.add(btnModificar);

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        panelBotones.add(btnEliminar);

        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLimpiar.setText("Limpiar Campos");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        panelBotones.add(btnLimpiar);

        btnSalir.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        panelBotones.add(btnSalir);

        getContentPane().add(panelBotones, java.awt.BorderLayout.SOUTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Evento: Registrar un nuevo empleado.
     */
    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        if (!validarCampos()) {
            return;
        }

        String id = txtId.getText().trim();

        // Verificar si el ID ya existe
        if (existeId(id)) {
            mostrarMensaje("Ya existe un empleado registrado con el Código / Cédula: " + id, 
                           "ID Duplicado", JOptionPane.WARNING_MESSAGE);
            txtId.requestFocus();
            return;
        }

        String nombres = txtNombres.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String correo = txtCorreo.getText().trim();
        String departamento = cbxDepartamento.getSelectedItem().toString();
        String cargo = cbxCargo.getSelectedItem().toString();
        double salario = Double.parseDouble(txtSalario.getText().trim().replace(",", "."));
        String estado = cbxEstado.getSelectedItem().toString();

        registro nuevoEmpleado = new registro(id, nombres, apellidos, telefono, correo, 
                                              departamento, cargo, salario, estado);

        agregarEmpleadoAListaYTabla(nuevoEmpleado);
        actualizarEstadisticas();
        limpiarCampos();

        mostrarMensaje("Empleado '" + nombres + " " + apellidos + "' registrado correctamente.", 
                       "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnRegistrarActionPerformed

    /**
     * Evento: Modificar los datos del empleado seleccionado.
     */
    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila = tblEmpleados.getSelectedRow();
        if (fila == -1) {
            mostrarMensaje("Por favor seleccione un empleado en la tabla para modificar.", 
                           "Ninguna Selección", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!validarCampos()) {
            return;
        }

        String id = txtId.getText().trim();
        String nombres = txtNombres.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String correo = txtCorreo.getText().trim();
        String departamento = cbxDepartamento.getSelectedItem().toString();
        String cargo = cbxCargo.getSelectedItem().toString();
        double salario = Double.parseDouble(txtSalario.getText().trim().replace(",", "."));
        String estado = cbxEstado.getSelectedItem().toString();

        // Actualizar en la lista interna
        for (registro emp : listaEmpleados) {
            if (emp.getId().equalsIgnoreCase(id)) {
                emp.setNombres(nombres);
                emp.setApellidos(apellidos);
                emp.setTelefono(telefono);
                emp.setCorreo(correo);
                emp.setDepartamento(departamento);
                emp.setCargo(cargo);
                emp.setSalario(salario);
                emp.setEstado(estado);
                break;
            }
        }

        // Actualizar en el modelo visual de la tabla
        modeloTabla.setValueAt(id, fila, 0);
        modeloTabla.setValueAt(nombres, fila, 1);
        modeloTabla.setValueAt(apellidos, fila, 2);
        modeloTabla.setValueAt(telefono, fila, 3);
        modeloTabla.setValueAt(correo, fila, 4);
        modeloTabla.setValueAt(departamento, fila, 5);
        modeloTabla.setValueAt(cargo, fila, 6);
        modeloTabla.setValueAt(String.format("%.2f", salario), fila, 7);
        modeloTabla.setValueAt(estado, fila, 8);

        actualizarEstadisticas();
        limpiarCampos();

        mostrarMensaje("Datos del empleado actualizados exitosamente.", 
                       "Modificación Exitosa", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnModificarActionPerformed

    /**
     * Evento: Eliminar el empleado seleccionado.
     */
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tblEmpleados.getSelectedRow();
        if (fila == -1) {
            mostrarMensaje("Por favor seleccione un empleado en la tabla para eliminar.", 
                           "Ninguna Selección", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String id = modeloTabla.getValueAt(fila, 0).toString();
        String nombreCompleto = modeloTabla.getValueAt(fila, 1).toString() + " " + 
                               modeloTabla.getValueAt(fila, 2).toString();

        int confirmacion = JOptionPane.showConfirmDialog(
            this, 
            "¿Está seguro de que desea eliminar al empleado?\n" + id + " - " + nombreCompleto, 
            "Confirmar Eliminación", 
            JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            // Eliminar de la lista interna
            listaEmpleados.removeIf(emp -> emp.getId().equalsIgnoreCase(id));

            // Eliminar fila de la tabla
            modeloTabla.removeRow(fila);

            actualizarEstadisticas();
            limpiarCampos();

            mostrarMensaje("El empleado ha sido eliminado correctamente.", 
                           "Empleado Eliminado", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    /**
     * Evento: Limpiar todos los campos del formulario.
     */
    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    /**
     * Evento: Salir del sistema con confirmación.
     */
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        int confirmacion = JOptionPane.showConfirmDialog(
            this, 
            "¿Desea cerrar el Sistema de Registro de Empleados?", 
            "Confirmar Salida", 
            JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            this.dispose();
            System.exit(0);
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    /**
     * Evento: Seleccionar una fila de la tabla para cargar datos en el formulario.
     */
    private void tblEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEmpleadosMouseClicked
        int fila = tblEmpleados.getSelectedRow();
        if (fila != -1) {
            txtId.setText(modeloTabla.getValueAt(fila, 0).toString());
            txtNombres.setText(modeloTabla.getValueAt(fila, 1).toString());
            txtApellidos.setText(modeloTabla.getValueAt(fila, 2).toString());
            txtTelefono.setText(modeloTabla.getValueAt(fila, 3).toString());
            txtCorreo.setText(modeloTabla.getValueAt(fila, 4).toString());

            String depto = modeloTabla.getValueAt(fila, 5).toString();
            cbxDepartamento.setSelectedItem(depto);

            String cargo = modeloTabla.getValueAt(fila, 6).toString();
            cbxCargo.setSelectedItem(cargo);

            String salario = modeloTabla.getValueAt(fila, 7).toString();
            txtSalario.setText(salario);

            String estado = modeloTabla.getValueAt(fila, 8).toString();
            cbxEstado.setSelectedItem(estado);

            // Bloquear el ID para evitar alteración accidental durante la edición
            txtId.setEditable(false);

            // Habilitar botones de acción sobre el registro seleccionado
            btnModificar.setEnabled(true);
            btnEliminar.setEnabled(true);
            btnRegistrar.setEnabled(false);
        }
    }//GEN-LAST:event_tblEmpleadosMouseClicked

    /**
     * Evento: Buscar empleados por ID, Nombre, Apellido, Departamento o Cargo.
     */
    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String busqueda = txtBuscar.getText().trim().toLowerCase();
        if (busqueda.isEmpty()) {
            recargarTabla();
            return;
        }

        modeloTabla.setRowCount(0);
        int coincidencias = 0;

        for (registro emp : listaEmpleados) {
            if (emp.getId().toLowerCase().contains(busqueda) ||
                emp.getNombres().toLowerCase().contains(busqueda) ||
                emp.getApellidos().toLowerCase().contains(busqueda) ||
                emp.getDepartamento().toLowerCase().contains(busqueda) ||
                emp.getCargo().toLowerCase().contains(busqueda)) {
                
                modeloTabla.addRow(emp.toTableRow());
                coincidencias++;
            }
        }

        if (coincidencias == 0) {
            mostrarMensaje("No se encontraron empleados con el criterio: '" + busqueda + "'.", 
                           "Sin Resultados", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    /**
     * Evento: Mostrar todos los empleados y limpiar el campo de búsqueda.
     */
    private void btnMostrarTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarTodosActionPerformed
        txtBuscar.setText("");
        recargarTabla();
    }//GEN-LAST:event_btnMostrarTodosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            try {
                javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // Look and feel predeterminado
            }
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formulario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnMostrarTodos;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<String> cbxCargo;
    private javax.swing.JComboBox<String> cbxDepartamento;
    private javax.swing.JComboBox<String> cbxEstado;
    private javax.swing.JScrollPane jScrollPaneTabla;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblCargo;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblDepartamento;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNombres;
    private javax.swing.JLabel lblNomina;
    private javax.swing.JLabel lblPromedioSalario;
    private javax.swing.JLabel lblSalario;
    private javax.swing.JLabel lblSubtitulo;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTotalEmpleados;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelBusqueda;
    private javax.swing.JPanel panelCuerpo;
    private javax.swing.JPanel panelEstadisticas;
    private javax.swing.JPanel panelFormulario;
    private javax.swing.JPanel panelEncabezado;
    private javax.swing.JPanel panelTablaContenedor;
    private javax.swing.JTable tblEmpleados;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JTextField txtSalario;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
