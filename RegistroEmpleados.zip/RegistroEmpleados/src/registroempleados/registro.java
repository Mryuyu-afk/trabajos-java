package registroempleados;

/**
 * Modelo de datos que representa a un Empleado en el sistema.
 * 
 * @author yurge
 */
public class registro {
    private String id;
    private String nombres;
    private String apellidos;
    private String telefono;
    private String correo;
    private String departamento;
    private String cargo;
    private double salario;
    private String estado;

    // Constructor vacío
    public registro() {
    }

    // Constructor completo
    public registro(String id, String nombres, String apellidos, String telefono, 
                    String correo, String departamento, String cargo, 
                    double salario, String estado) {
        this.id = id;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.correo = correo;
        this.departamento = departamento;
        this.cargo = cargo;
        this.salario = salario;
        this.estado = estado;
    }

    // Getters y Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Convierte los datos del objeto a una fila de JTable.
     * @return arreglo de objetos para el DefaultTableModel
     */
    public Object[] toTableRow() {
        return new Object[] {
            id,
            nombres,
            apellidos,
            telefono,
            correo,
            departamento,
            cargo,
            String.format("%.2f", salario),
            estado
        };
    }

    @Override
    public String toString() {
        return id + " - " + nombres + " " + apellidos + " (" + cargo + ")";
    }
}
