/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package veterinaria;

/**
 *
 * @author yurge
 */
public class Veterinaria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mascota mascotas = new mascota();
        
        mascotas.setnombre("molly");
        mascotas.setespecie("chitzu");
        mascotas.setedad(3);
        
        System.out.println("informacion de la mascota");
        System.out.println("nombre: " + mascotas.getnombre());
        System.out.println("especie: " + mascotas.getespecie());
        System.out.println("edad: " + mascotas.getedad());
        
        
    }
    
}
