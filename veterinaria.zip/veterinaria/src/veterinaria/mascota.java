/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veterinaria;

/**
 *
 * @author yurge
 */
public class mascota {

private String nombre;
private String especie;
private int edad;

public String getnombre(){
return  nombre;
        }
public void setnombre(String nombre){
this.nombre = nombre;
}
public String getespecie(){
return  especie;
        }
public void setespecie(String especie){
this.especie = especie;
}

public int getedad(){
return edad;
 }
public void setedad(int edad){
this.edad = edad;
}
}

    
   
    
    

