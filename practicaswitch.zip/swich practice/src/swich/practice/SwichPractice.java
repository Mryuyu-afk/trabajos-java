/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package swich.practice;
import java.util.Scanner;

public class SwichPractice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero1 = 2;
        int numero2 = 4;
        int resultado = 0;
        int parametro = 0;
        
        Scanner entrada = new Scanner(System.in);
        
        
        System.out.println("seleccione una opcion:");
        System.out.println("1 + suma");
        System.out.println("2 - resta");
        System.out.println("3 / divicion");
        System.out.println("4 * multiplicacion");
        System.out.print("opcion: ");
        
        //
     parametro = entrada.nextInt();
        
         
        switch(parametro){
            
            case 1 : resultado = numero1 + numero2;
                System.out.println("el resultado de la suma es: " + resultado);
                
                
                break;
                case 2 : resultado = numero1 - numero2;
                System.out.println("el resultado de la resta es: " + resultado);
                
                
                break;
                case 3 : resultado = numero1 * numero2;
                System.out.println("el resultado de la multiplicacion es: " + resultado);
                
                
                break;
                case 4 : resultado = numero1 / numero2;
                System.out.println("el resultado de la divicion es: " + resultado);
                
                
                break;
                default: System.out.println("la opcion digitada no es correcta");
                
                
                break;
        }
    }
    
}
