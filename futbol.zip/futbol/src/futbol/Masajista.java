/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package futbol;

/**
 *
 * @author yurge
 */
public class Masajista extends seleccionFutbol{
    
    String Titulacion;
    int añosExperiencia;
    
    public Masajista(){
    super();
    }

    public Masajista(String Titulacion, int añosExperiencia, int id, String Apellidos, String nombre, int edad) {
        super(id, Apellidos, nombre, edad);
        this.Titulacion = Titulacion;
        this.añosExperiencia = añosExperiencia;
    }
  public String setTitulacion(){
  
  return Titulacion;
  }
  public void getTitulacion(String Titulacion){
      
  this.Titulacion = Titulacion;
  }
  
  public int setañosExperiencia(){
  
  return añosExperiencia;
  }
  
  public void getañosExperiencia(int añosExperiencia){
  this.añosExperiencia = añosExperiencia;
  } 
  
  public void daraMasaje(){}
  
  @Override
    public void viajar(){
        System.out.println("el masajista esta viaja");
    }
    @Override
    public void concentrarse(){
        System.out.println("el masajista se concentra");
    }
}
